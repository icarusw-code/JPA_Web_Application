package jpabook.jbashop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JbashopApplication {

	public static void main(String[] args) {
		SpringApplication.run(JbashopApplication.class, args);
	}

}
